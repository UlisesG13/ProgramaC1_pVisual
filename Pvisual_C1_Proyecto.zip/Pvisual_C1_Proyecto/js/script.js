const listaUsuarios = [{usuario:"valorUsuario", pass:"valorPassword", mensaje:"valorMensaje"}];
localStorage.setItem("lista",JSON.stringify(listaUsuarios))

document.addEventListener('DOMContentLoaded', (event) => {
  const button = document.querySelector('.corner-button');
  const body = document.body;
  
  button.addEventListener('mouseout', () => {
    body.style.backgroundImage = "url('img/dog.jpg')";
  });

  button.addEventListener('mouseover', () => {
    body.style.backgroundImage = "url('img/dogHappy.jpg')";
  });

 
  button.addEventListener('click', () => {
    window.location.href = 'index2.html'; 
  });
});