const guardar=()=>{
    
    listaUsuarios=JSON.parse(localStorage.getItem("lista"));
    let valorUsuario = document.getElementById("RUser").value;
    let valorPassword = document.getElementById("RPass").value;
    let valorMensaje = document.getElementById("RMens").value;
    let mensaje = "dddddd";

    
        let objeto={usuario:valorUsuario, pass:valorPassword, mensaje:valorMensaje};
        listaUsuarios.push(objeto);
        mensaje="Usuario creado";
        localStorage.setItem("lista",JSON.stringify(listaUsuarios));
        for (let i = 0; i<listaUsuarios.length; i++) {
            mensaje = listaUsuarios[i].usuario + " " + listaUsuarios[i].pass + " " + listaUsuarios[i].mensaje;
        }
    
    alert(mensaje);
    console.log(listaUsuarios);
    Swal.fire({
        title: "Good job!",
        text: "You clicked the button!",
        icon: "success"
      });
}
